// #include <iostream>
// #include <vector>
// #include<sstream>
// #include<fstream>
// #include<cstdlib>
// #include"CandyLand.h"


// using namespace std;

// int countTimes(string s, char seperator);
// int split(string input, char seperator, string arr[], int arr_size);
// int numCharacters(string filename);





// void CandyLand::loadCharacters(string filename)
// {
//     /*
//     1. create a stringstream
//     2. create a for loop to run 4 times
//         - use getline with the appropriate deliminator to get the name, gold, stamina and a string of candies
//         - use split function to fill an array of candies with the appropriate candies by name
//         - save this Character struct object in the _characters array
//     */



//     // ifstream filein;
//     // filein.open(filename);
//     // string line;
//     // Character characters[numCharacters(filename)];
//     // int index=0;
//     // while(!filein.eof())
//     // {
//     //     string name, candie, s_stamina, s_gold;
//     //     int stamina, gold;
//     //     Candy candies[];
        
//     //     getline(filein, line);
//     //     stringstream ss (line);
//     //     getline(ss, name, '|');
//     //     getline(ss, s_stamina, '|');
//     //     stamina=stoi(s_stamina);
//     //     getline(ss, s_gold, '|');
//     //     gold=stoi(s_gold);
//     //     getline(ss, candie);



//     //     Character c1;
//     //     c1.name=name;
//     //     c1.stamina=stamina;
//     //     c1.gold=gold;
//     //     c1.invSize=split(candie, ',', candies, countTimes(candie));
//     //     c1.candies=candies;
        
//     //     characters[index]=c1;
//     //     index++;
//     // }
// }

// void CandyLand::loadCandies(string filename)
// {
//     /*
//     1. Declares and initializes a counting variable to be 0
//     2. creates a filein and has a while loop that runs until .eof is true
//         - creates a temporary candy object
//         - uses getline() with each line being made a stringstream to get the variables about the candy from the file
//         - sets the temporary candy object's values to the appropriate ones from the file
//         - adds the temporary candy to the array at the index of the counting variable
//         - increments the counting variable
//     3. sets _numCandies to the counting variable
//     */
// }

// void CandyLand::setupGame()
// {
//     /*
//     1. calls the loadCharacters()
//     2. calls the loadCandies()
//     3. creates 3 new CandyStore objects with random candies determined by three random candies from the _candies list
    
//     */
// }

// Candy CandyLand::randomCandy()
// {
//     /*
//     returns a random candy from the candy list. used to populate stores.
//     */
// }

// void CandyLand::setupBoard()
// {
//     /*
//     1. creates 3 new CandyStore objects with random candies determined by three random candies from the _candies list
//     2. assigns each of the the candy stores a random number from the list of random positions they can be at (_firstPos, _secondPos, or _thirdPos)

//     2. creates a board object() and passes in the three candyStores
//     3. 
//     */
// }

// Card CandyLand::drawCard()
// {
//     string cards[3] = {"Cotton Candy Magenta card", "Minty Green card", "Bubblegum blue card"};
//     Card temp;
//     int j=rand()%3;
//     temp.color=cards[j]
//     temp.name=cards[j]

//     if(rand()%5<1)
//     {
//         temp.dbl=true;
//         string tmp=temp.name
//         temp.name="Dobule " + tmp;
//     }

//     return temp;
// }
// void CandyLand::move(Player player, Card card)
// {
//     int current= player.getposition();
//     int type=1;

//     if(card.name.at(0)=='C') //If magenta card
//     {
//         if(current%3=0)
//     {
//         if(card.dbl==true) 
//         {
//             player.setPosition(current+6);
//         }
//         else 
//         {
//             player.setPosition(current+3)
//         }
        
//     }
//     if(current%3=1)
//     {
//         if(card.dbl==true) 
//         {
//             player.setPosition(current+4);
//         }
//         else 
//         {
//             player.setPosition(current+1)
//         }
//     }
//     if(current%3=2)
//     {
//         if(card.dbl==true) 
//         {
//             player.setPosition(current+5);
//         }
//         else 
//         {
//             player.setPosition(current+2)
//         }
//     }
//     }

//     if(card.name.at(0)=='M') //If green
//     {
//         if(current%3=0)
//     {
//         if(card.dbl==true) 
//         {
//             player.setPosition(current+5);
//         }
//         else 
//         {
//             player.setPosition(current+2)
//         }
        
//     }
//     if(current%3=1)
//     {
//         if(card.dbl==true) 
//         {
//             player.setPosition(current+3);
//         }
//         else 
//         {
//             player.setPosition(current+6)
//         }
//     }
//     if(current%3=2)
//     {
//         if(card.dbl==true) 
//         {
//             player.setPosition(current+4);
//         }
//         else 
//         {
//             player.setPosition(current+1)
//         }
//     }
//     }

//     if(card.name.at(0)=='B') //If blue
//     {
//         if(current%3=0)
//     {
//         if(card.dbl==true) 
//         {
//             player.setPosition(current+5);
//         }
//         else 
//         {
//             player.setPosition(current+2)
//         }
        
//     }
//     if(current%3=1)
//     {
//         if(card.dbl==true) 
//         {
//             player.setPosition(current+4);
//         }
//         else 
//         {
//             player.setPosition(current+1)
//         }
//     }
//     if(current%3=2)
//     {
//         if(card.dbl==true) 
//         {
//             player.setPosition(current+6);
//         }
//         else 
//         {
//             player.setPosition(current+3)
//         }
//     }
//     }

    
    

// }

// void useCandy()

// void startGame()
// {
//     srand(time(0))
//     /*
//     1. prompt how many people will play and save this to an int. currently 2 people
//     2. for loop to go repeat once for each player, asking them what character they want to be and printing out the list of characters. the info from selected character is then put into 
//     a player in the array of players.
//     3. there is a loop that goes until a players position reaches within 5 tiles of the castle at the end of the board with an integrer alternating between 1 and 2 to determine what player is playing
//         - each loop starts off by displaying whose turn it is and offering them three options. take card, use candy or show stats
//         - showing stats will show player info them prompt again
//         - take card will randomly generate a card using the drawCard method
//         - the card will be displayed and then the players position will be updated with the move function
//         - if the player chooses to use a candy, their candies will be displayed and they type in the candy they want to use and it goes to the useCandy function

//     */
// }




// int split(string input, char seperator, string arr[], int arr_size)
// {
//     if(int(input.length())==0 || arr_size==0) // Returns 0 if the string doesnt exist
//     {
//         return 0;
//     }
//     string segment;
//     int index=0;
//     stringstream ss (input);
//     while(!ss.eof())
//     {
//         getline(ss, segment, seperator);
//         if(index<arr_size)
//         {
//             arr[index]=segment;
//             index++;
//         }
//         else{
//             return -1;
//         }
//     }
//     return index;
// }

// int countTimes(string s, char seperator){
//     if(s.size()==0) return 0;
//     int ret=1;
//     for(int i=0;i<s.size();i++)
//     {
//         if(s.at(i)==seperator) ret++;
//     }
//     return ret;
// }





