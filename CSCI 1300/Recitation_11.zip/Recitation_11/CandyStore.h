#ifndef CANDYSTORE_H
#define CANDYSTORE_H

// CSCI 1300 Fall 2023
// Author: August Penny
// TA: Guarav Roy
// CandyStore.h

#include<iostream>
#include"Board.h"
using namespace std;

class CandyStore
{
    public:
        CandyStore();
        CandyStore(string store_name);
        bool addCandy(Candy candy);
        bool removeCandy(string candy_name);
        void displayCandies();
    private:
        string _store_name;
        const static int _MAX_CANDIES = 5;
        Candy _candies[_MAX_CANDIES];
        int _candy_count;

};

#endif